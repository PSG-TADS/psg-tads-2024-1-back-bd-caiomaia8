﻿using System.ComponentModel.DataAnnotations;

namespace TrabalhoAPI.Models
{
    public class Veiculo
    {
        [Key]
        public int VeiculoID { get; set; }
        // Primária

        public string? Modelo { get; set; }
        public string? Marca { get; set; }
        public int Ano { get; set; }
        public string? Placa { get; set; }
        public string? Status { get; set; }

        // Relação com a classe reserva
        public ICollection<Reserva>? Reservas { get; set; }

    }
}
