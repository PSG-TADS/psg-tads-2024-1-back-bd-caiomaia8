﻿using System.ComponentModel.DataAnnotations;

namespace TrabalhoAPI.Models
{
    public class Cliente
    {
        [Key]
        public int ClienteID { get; set; }
        // Primária

        public string? Nome { get; set; }
        public string? Telefone { get; set; }
        public string? Endereco { get; set; }

        public string? Email { get; set; }

        // Relação com a classe reserva
        public ICollection<Reserva>? Reservas { get; set; }
    }
}
