﻿using Microsoft.EntityFrameworkCore;

namespace TrabalhoAPI.Models
{
    public class ApplicationDbContext : DbContext //classe responsável pelo contexto de conexão
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        { 
        }

        public DbSet<Veiculo> Veiculos { get; set; }
        public DbSet<Cliente> Clientes { get; set; }

        public DbSet<Reserva> Reservas { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) // string de conexão
        {
            _ = optionsBuilder.UseSqlServer(@"Server=.\SQLEXPRESS;Database=TP01;Trusted_Connection=True;TrustServerCertificate=true");
        }
    
    }
}
