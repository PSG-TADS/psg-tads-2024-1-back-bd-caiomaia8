﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace TrabalhoAPI.Models
{
    public class Reserva
    {
        [Key]
        public int ReservaID { get; set; }
        //Primária

        public int VeiculoID { get; set; } // Estrangeira veiculo
        public int ClienteID { get; set; } // Estrangeira cliente
        public DateTime Inicio { get; set; }
        public DateTime Fim { get; set; }

        // Definida a chave estrangeira para veículo
        [ForeignKey("VeiculoID")]
        public Veiculo? Veiculo { get; set; }

        // Definida a chave estrangeira para cliente
        [ForeignKey("ClienteID")]
        public Cliente? Cliente { get; set; }
    }
}
