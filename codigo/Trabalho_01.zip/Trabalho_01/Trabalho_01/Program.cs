﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LocadoraVeiculos
{
    internal class Program
    {
        // Classe Veiculo
        public class Veiculo
        {
            [Key]
            public int VeiculoID { get; set; } 
            // Primária

            public string? Modelo { get; set; }
            public string? Marca { get; set; }
            public int Ano { get; set; }
            public string? Placa { get; set; }
            public string? Status { get; set; }
          
            // Relação com a classe reserva
            public ICollection<Reserva>? Reservas { get; set; }
        }

        // Classe Cliente
        public class Cliente
        {
            [Key]
            public int ClienteID { get; set; } 
            // Primária

            public string? Nome { get; set; }
            public string? Telefone { get; set; }
            public string? Endereco { get; set; }
            
            public string? Email { get; set; }

            // Relação com a classe reserva
            public ICollection<Reserva>? Reservas { get; set; }
        }

        // Classe Reserva
        public class Reserva
        {
            [Key]
            public int ReservaID { get; set; } 
            //Primária

            public int VeiculoID { get; set; } // Estrangeira veiculo
            public int ClienteID { get; set; } // Estrangeira cliente
            public DateTime Inicio { get; set; }
            public DateTime Fim { get; set; }

            // Definida a chave estrangeira para veículo
            [ForeignKey("VeiculoID")]
            public Veiculo? Veiculo { get; set; }

            // Definida a chave estrangeira para cliente
            [ForeignKey("ClienteID")]
            public Cliente? Cliente { get; set; }
        }
    }
}
